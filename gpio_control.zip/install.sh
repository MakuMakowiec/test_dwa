#!/bin/bash

echo "Installing gpio_control"

echo "plugininstallend"
